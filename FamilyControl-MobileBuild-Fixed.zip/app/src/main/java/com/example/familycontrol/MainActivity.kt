package com.example.familycontrol

import android.Manifest
import android.app.Activity
import android.content.pm.PackageManager
import android.location.Location
import android.location.LocationManager
import android.os.Bundle
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import android.view.ViewGroup
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat

class MainActivity : Activity() {
    private lateinit var status: TextView
    private val requestCodeLocation = 101

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(40, 48, 40, 40)
        }

        val title = TextView(this).apply {
            text = "Family Control — Starter"
            textSize = 24f
        }
        val note = TextView(this).apply {
            text = "Prototype only. Location is read only after you tap the button and grant permission. No data is uploaded or shared."
            textSize = 16f
            setPadding(0, 24, 0, 24)
        }
        status = TextView(this).apply {
            text = "Choose a role, then test location on this phone."
            textSize = 16f
            setPadding(0, 12, 0, 24)
        }

        val parentButton = Button(this).apply {
            text = "Set up this phone as Parent"
            setOnClickListener {
                status.text = "Parent mode selected. A secure account/backend is needed to receive another phone's shared location."
            }
        }
        val childButton = Button(this).apply {
            text = "Set up this phone as Child"
            setOnClickListener {
                status.text = "Child mode selected. Location sharing is not connected yet; this starter does not transmit location."
            }
        }
        val locationButton = Button(this).apply {
            text = "Show this phone's location"
            setOnClickListener { checkPermissionAndShowLocation() }
        }

        layout.addView(title)
        layout.addView(note)
        layout.addView(parentButton, matchWidth())
        layout.addView(childButton, matchWidth())
        layout.addView(locationButton, matchWidth())
        layout.addView(status)
        setContentView(layout)
    }

    private fun matchWidth(): LinearLayout.LayoutParams =
        LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)

    private fun checkPermissionAndShowLocation() {
        val fine = ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
        val coarse = ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION)
        if (fine != PackageManager.PERMISSION_GRANTED && coarse != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(
                this,
                arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION),
                requestCodeLocation
            )
            return
        }
        showLastKnownLocation()
    }

    private fun showLastKnownLocation() {
        try {
            val manager = getSystemService(LOCATION_SERVICE) as LocationManager
            val providers = manager.getProviders(true)
            var best: Location? = null
            for (provider in providers) {
                val candidate = try { manager.getLastKnownLocation(provider) } catch (_: SecurityException) { null }
                if (candidate != null && (best == null || candidate.accuracy < best!!.accuracy)) best = candidate
            }
            if (best == null) {
                status.text = "No recent location available. Turn on Location and try again outdoors."
            } else {
                status.text = "This phone's last known location:\nLatitude: ${best.latitude}\nLongitude: ${best.longitude}\n\nThis stays on this phone in this prototype."
            }
        } catch (_: Exception) {
            status.text = "Couldn't read location. Check Location settings and permission."
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == requestCodeLocation) {
            if (grantResults.any { it == PackageManager.PERMISSION_GRANTED }) showLastKnownLocation()
            else Toast.makeText(this, "Location permission was not granted.", Toast.LENGTH_LONG).show()
        }
    }
}
