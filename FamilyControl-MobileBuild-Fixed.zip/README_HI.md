# Family Control - Starter Project

## Important status
This is a starter/demo app, not a finished parental-control product. It currently provides a basic Parent/Child mode selection and a permission-based display of this phone's last-known location. It does NOT yet send location between phones and does NOT implement screen mirroring or a backend.

## Build an APK using a phone and GitHub
1. Create/sign in to GitHub and create a new repository.
2. Extract this ZIP on your phone.
3. Upload the contents of this ZIP to the repository root. The root should show `settings.gradle.kts`, `build.gradle.kts`, `app/`, and `.github/`. Do not upload an extra enclosing folder.
4. Open the repository's Actions tab and enable Actions if prompted.
5. Open `Build Android APK` and tap `Run workflow` (or push files to `main`).
6. After a successful run, open the run and download the `FamilyControl-debug-apk` artifact. Extract it to get `app-debug.apk`.
7. Install only on devices you own or have permission to manage. Android may ask to allow installation from your file manager.

## Features still requiring development
- Secure parent/child pairing and backend.
- Consent-based location updates from child device to parent device.
- Screen mirroring using Android MediaProjection consent UI and secure WebRTC transport.
- Visible sharing status, pause/revoke controls, unlinking, and security testing.

A successful APK build only means this starter compiles; it does not mean location sharing or screen mirroring are implemented. No stealth monitoring or permission bypasses.
